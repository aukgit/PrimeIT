<?php require_once("functions.php") ?>

<?php 
    Global $Connection;
    $Connection = getConnection("testpurpose");
    $results = data_table_Rows_view($Connection, "Select * from person");
    //echo "</br><pre>" ;print_r( $results ) ;echo "</pre></br>" ; die(); 
    $count_rows = count($results);
?>

<table>
    <thead>

        <th>First Name</th>
        <th>Last Name</th>
        <th>Date Of Birth</th>
    </thead>
    <tbody>
        <?php 
            if($count_rows > 0) {
                foreach ($results as $row) {
                    echo "<tr>";
                    foreach ($row as $col => $val) {
                        if($col>=1){
                            echo "<td>" . $val .  "</td>";
                        }
                    }
                    echo "</tr>";
                }
            }
        ?>
       
    </tbody>
    
</table>